// FUNÇÕES GERAIS DO SITE

// Menu Mobile
document.addEventListener('DOMContentLoaded', function() {
    // Selecionar elementos
    const menuMobile = document.querySelector('.menu-mobile');
    const nav = document.querySelector('.nav');
    
    // Abrir/Fechar menu mobile
    menuMobile.addEventListener('click', function() {
        nav.classList.toggle('active');
    });
    
    // Fechar menu ao clicar em um link
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                nav.classList.remove('active');
            }
        });
    });
    
    // Efeito de scroll suave para links internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Adicionar classe ativa ao item de menu conforme scroll
    window.addEventListener('scroll', function() {
        if (window.innerWidth > 768) {
            const sections = document.querySelectorAll('section');
            let current = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (pageYOffset >= sectionTop - 100) {
                    current = section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        }
    });
});

// Carrossel (pode ser implementado posteriormente)
function initCarrossel() {
    // Implementação futura de carrossel no banner
}
// CONTROLE DO HEADER SCROLL
const header = document.querySelector('.header');
const banner = document.querySelector('.banner');

window.addEventListener('scroll', () => {
  const scrollPosition = window.scrollY;
  
  if (scrollPosition > 100) {
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
  
  // Efeito parallax no banner
  if (banner) {
    banner.style.backgroundPositionY = `${scrollPosition * 0.5}px`;
  }
});

// MENU MOBILE AVANÇADO
document.addEventListener('DOMContentLoaded', function() {
  const menuMobile = document.querySelector('.menu-mobile');
  const nav = document.querySelector('.nav');
  
  menuMobile.addEventListener('click', function() {
    nav.classList.toggle('active');
    this.classList.toggle('active');
  });
  
  // Fechar menu ao clicar em um link
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function() {
      if (window.innerWidth <= 768) {
        nav.classList.remove('active');
        menuMobile.classList.remove('active');
      }
    });
  });
  
  // SCROLL SUAVE PARA TODOS OS LINKS
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 100,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // ANIMAÇÃO DE SCROLL PARA AS SEÇÕES
  const animateOnScroll = () => {
    const sections = document.querySelectorAll('.secao-pais, .intro, .destaques');
    
    sections.forEach(section => {
      const sectionTop = section.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;
      
      if (sectionTop < windowHeight - 100) {
        section.style.opacity = '1';
        section.style.transform = 'translateY(0)';
      }
    });
  };
  
  // Configura animações iniciais
  document.querySelectorAll('.secao-pais, .intro, .destaques').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  });
  
  // Ativa animações quando a página carrega
  setTimeout(animateOnScroll, 300);
  
  // Ativa animações durante o scroll
  window.addEventListener('scroll', animateOnScroll);
  
  // CARREGAMENTO OTIMIZADO DE IMAGENS
  const lazyLoadImages = () => {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          observer.unobserve(img);
          
          // Adiciona efeito de fade-in quando a imagem carrega
          img.style.opacity = '0';
          img.style.transition = 'opacity 0.5s ease';
          setTimeout(() => {
            img.style.opacity = '1';
          }, 100);
        }
      });
    });
    
    images.forEach(img => {
      imageObserver.observe(img);
    });
  };
  
  lazyLoadImages();
  
  // ATIVAÇÃO DAS ABAS INTERATIVAS
  const abasPais = document.querySelectorAll('.abas-pais a');
  
  abasPais.forEach(aba => {
    aba.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Remove classe ativa de todas as abas
      abasPais.forEach(a => a.classList.remove('active'));
      
      // Adiciona classe ativa na aba clicada
      this.classList.add('active');
      
      // Mostra a seção correspondente
      const targetId = this.getAttribute('href');
      const targetSection = document.querySelector(targetId);
      
      if (targetSection) {
        // Esconde todas as seções
        document.querySelectorAll('.secao-pais').forEach(sec => {
          sec.style.display = 'none';
        });
        
        // Mostra a seção alvo
        targetSection.style.display = 'block';
        
        // Scroll suave para a seção
        window.scrollTo({
          top: targetSection.offsetTop - 120,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Inicializa mostrando a primeira seção
  if (abasPais.length > 0) {
    const primeiraAba = document.querySelector('.abas-pais a.active');
    if (primeiraAba) {
      const primeiraSecao = document.querySelector(primeiraAba.getAttribute('href'));
      if (primeiraSecao) {
        document.querySelectorAll('.secao-pais').forEach(sec => {
          sec.style.display = 'none';
        });
        primeiraSecao.style.display = 'block';
      }
    }
  }
});

// CARROSSEL PARA O BANNER PRINCIPAL (OPCIONAL)
function initCarrossel() {
  const banner = document.querySelector('.banner');
  if (!banner) return;
  
  const imagens = [
    'url("../img/banner.jpg")',
    'url("../img/banner2.jpg")',
    'url("../img/banner3.jpg")'
  ];
  
  let currentIndex = 0;
  
  function changeBackground() {
    currentIndex = (currentIndex + 1) % imagens.length;
    banner.style.backgroundImage = imagens[currentIndex];
  }
  
  // Alterna a cada 5 segundos (opcional)
  setInterval(changeBackground, 5000);
}

// Inicializa o carrossel quando a página carrega
window.addEventListener('load', initCarrossel);
// Otimização de carregamento de imagens
function lazyLoadImages() {
    const images = document.querySelectorAll('img[loading="lazy"]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                
                // Carrega a imagem
                img.src = img.dataset.src || img.src;
                
                // Remove o estilo de loading quando carregada
                img.onload = () => {
                    img.style.background = 'none';
                    img.style.animation = 'none';
                };
                
                observer.unobserve(img);
            }
        });
    }, {
        rootMargin: '200px 0px' // Carrega 200px antes de entrar na viewport
    });
    
    images.forEach(img => {
        imageObserver.observe(img);
    });
}

// Inicializa quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', lazyLoadImages);