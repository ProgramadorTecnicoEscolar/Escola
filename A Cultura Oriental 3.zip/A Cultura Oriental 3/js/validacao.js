// VALIDAÇÃO DO FORMULÁRIO DE CADASTRO

document.addEventListener('DOMContentLoaded', function() {
    const formCadastro = document.getElementById('formCadastro');
    
    if (formCadastro) {
        formCadastro.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Resetar mensagens de erro
            resetarErros();
            
            // Validar campos
            const nomeValido = validarNome();
            const emailValido = validarEmail();
            const senhaValida = validarSenha();
            const confirmacaoValida = validarConfirmacaoSenha();
            
            // Se todos os campos forem válidos, enviar formulário
            if (nomeValido && emailValido && senhaValida && confirmacaoValida) {
                alert('Cadastro realizado com sucesso!');
                formCadastro.reset();
            }
        });
    }
    
    // Função para validar nome
    function validarNome() {
        const nomeInput = document.getElementById('nome');
        const nome = nomeInput.value.trim();
        const erroNome = nomeInput.nextElementSibling;
        
        if (nome === '') {
            erroNome.textContent = 'Por favor, insira seu nome completo.';
            nomeInput.focus();
            return false;
        }
        
        if (nome.length < 3) {
            erroNome.textContent = 'O nome deve ter pelo menos 3 caracteres.';
            nomeInput.focus();
            return false;
        }
        
        return true;
    }
    
    // Função para validar e-mail
    function validarEmail() {
        const emailInput = document.getElementById('email');
        const email = emailInput.value.trim();
        const erroEmail = emailInput.nextElementSibling;
        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email === '') {
            erroEmail.textContent = 'Por favor, insira seu e-mail.';
            emailInput.focus();
            return false;
        }
        
        if (!regexEmail.test(email)) {
            erroEmail.textContent = 'Por favor, insira um e-mail válido.';
            emailInput.focus();
            return false;
        }
        
        return true;
    }
    
    // Função para validar senha
    function validarSenha() {
        const senhaInput = document.getElementById('senha');
        const senha = senhaInput.value;
        const erroSenha = senhaInput.nextElementSibling;
        
        if (senha === '') {
            erroSenha.textContent = 'Por favor, insira uma senha.';
            senhaInput.focus();
            return false;
        }
        
        if (senha.length < 6) {
            erroSenha.textContent = 'A senha deve ter pelo menos 6 caracteres.';
            senhaInput.focus();
            return false;
        }
        
        return true;
    }
    
    // Função para validar confirmação de senha
    function validarConfirmacaoSenha() {
        const senhaInput = document.getElementById('senha');
        const confirmarSenhaInput = document.getElementById('confirmar-senha');
        const senha = senhaInput.value;
        const confirmarSenha = confirmarSenhaInput.value;
        const erroConfirmarSenha = confirmarSenhaInput.nextElementSibling;
        
        if (confirmarSenha === '') {
            erroConfirmarSenha.textContent = 'Por favor, confirme sua senha.';
            confirmarSenhaInput.focus();
            return false;
        }
        
        if (senha !== confirmarSenha) {
            erroConfirmarSenha.textContent = 'As senhas não coincidem.';
            confirmarSenhaInput.focus();
            return false;
        }
        
        return true;
    }
    
    // Função para resetar mensagens de erro
    function resetarErros() {
        const erros = document.querySelectorAll('.erro-mensagem');
        erros.forEach(erro => {
            erro.textContent = '';
        });
    }
});
// VALIDAÇÃO DE FORMULÁRIO AVANÇADA
document.addEventListener('DOMContentLoaded', function() {
  const formCadastro = document.getElementById('formCadastro');
  
  if (formCadastro) {
    // Validação em tempo real
    formCadastro.querySelectorAll('input').forEach(input => {
      input.addEventListener('input', function() {
        validarCampo(this);
      });
      
      input.addEventListener('blur', function() {
        validarCampo(this);
      });
    });
    
    // Validação no submit
    formCadastro.addEventListener('submit', function(e) {
      e.preventDefault();
      
      let formValido = true;
      const campos = formCadastro.querySelectorAll('input[required]');
      
      campos.forEach(campo => {
        if (!validarCampo(campo)) {
          formValido = false;
        }
      });
      
      if (formValido) {
        // Animação de sucesso
        formCadastro.classList.add('submitting');
        
        // Simulação de envio (substituir por AJAX real)
        setTimeout(() => {
          formCadastro.classList.remove('submitting');
          formCadastro.classList.add('success');
          
          // Feedback visual
          const successMessage = document.createElement('div');
          successMessage.className = 'success-message';
          successMessage.innerHTML = `
            <svg viewBox="0 0 24 24">
              <path fill="currentColor" d="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z" />
            </svg>
            <p>Cadastro realizado com sucesso!</p>
          `;
          
          formCadastro.appendChild(successMessage);
          
          // Reset após 3 segundos
          setTimeout(() => {
            formCadastro.reset();
            formCadastro.classList.remove('success');
            successMessage.remove();
          }, 3000);
        }, 1500);
      }
    });
  }
  
  // Função para validar campos individuais
  function validarCampo(campo) {
    const valor = campo.value.trim();
    const erro = campo.nextElementSibling;
    let valido = true;
    
    // Resetar estado
    campo.classList.remove('invalido');
    erro.textContent = '';
    
    // Validações específicas
    switch (campo.id) {
      case 'nome':
        if (valor === '') {
          erro.textContent = 'Por favor, insira seu nome completo.';
          valido = false;
        } else if (valor.length < 3) {
          erro.textContent = 'O nome deve ter pelo menos 3 caracteres.';
          valido = false;
        }
        break;
        
      case 'email':
        if (valor === '') {
          erro.textContent = 'Por favor, insira seu e-mail.';
          valido = false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valor)) {
          erro.textContent = 'Por favor, insira um e-mail válido.';
          valido = false;
        }
        break;
        
      case 'senha':
        if (valor === '') {
          erro.textContent = 'Por favor, insira uma senha.';
          valido = false;
        } else if (valor.length < 6) {
          erro.textContent = 'A senha deve ter pelo menos 6 caracteres.';
          valido = false;
        }
        break;
        
      case 'confirmar-senha':
        const senha = document.getElementById('senha').value;
        if (valor === '') {
          erro.textContent = 'Por favor, confirme sua senha.';
          valido = false;
        } else if (valor !== senha) {
          erro.textContent = 'As senhas não coincidem.';
          valido = false;
        }
        break;
    }
    
    // Aplicar estado visual
    if (!valido) {
      campo.classList.add('invalido');
      campo.focus();
    }
    
    return valido;
  }
});